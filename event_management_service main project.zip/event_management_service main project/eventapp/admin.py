from django.contrib import admin
from .models import UserBooking
# Register your models here.

admin.site.register(UserBooking)
