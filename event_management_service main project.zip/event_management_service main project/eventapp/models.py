from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class UserBooking(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    Date=models.DateField(unique=True)
    contact=models.BigIntegerField()
    event_name=models.CharField(max_length=20)
    customer_name=models.CharField(max_length=80)
    City=models.CharField(max_length=80)


    
