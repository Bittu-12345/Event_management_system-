from django.urls import path
from eventapp import views
from django.contrib.auth.views import LoginView
urlpatterns = [
    path('signup/',views.sign_up,name='signup'),
    path('login/',views.user_login,name='login'),
    path('profile/',views.profile,name='profile'),
    path('logout/',views.user_logout,name='logout'),
    path('delete_booking/<int:booking_id>/', views.delete_booking, name='delete_booking'),







      path("about/",views.about,name='about'),
       path('bookings/', views.booking, name='bookings'),
        path('',views.homepage,name='home'),
        
        path('prevoius/',views.previous, name='previous'),
        path('help/',views.help, name='help'),
       
]

