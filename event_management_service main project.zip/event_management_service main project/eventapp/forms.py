
from django import forms
from .models import UserBooking
from django.contrib.auth.models import User #it is already create models
from django.contrib.auth.forms import UserCreationForm
class BookingForm(forms.ModelForm):
    class Meta:
        model = UserBooking  # Specify the model for which the form is created
        fields = '__all__'
        widgets = {
            'Date': forms.DateInput(attrs={'type': 'date'}),
        }

class SignUpForm(UserCreationForm):
    class Meta:
        model=User
        fields=['username','first_name','last_name','email']
        labels={'email':"Email"}



    