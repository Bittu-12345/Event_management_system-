from django.shortcuts import render,HttpResponseRedirect,get_object_or_404,redirect
from .forms import BookingForm,SignUpForm
from .models import UserBooking
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate,login,logout

# Create your views here.
def about(request):
    return render(request,'about.html')
def homepage(request):
    return render(request,'base.html')
def profile(request):
    if request.user.is_authenticated:
        return render(request,'profile.html',{'name':request.user})
    else:
        return HttpResponseRedirect('/login/')

#login View
def user_login(request):
    if not request.user.is_authenticated:
        if request.method=="POST":
            fm=AuthenticationForm(request=request,data=request.POST)
            if fm.is_valid():
                uname=fm.cleaned_data['username']
                upass=fm.cleaned_data['password']
                user=authenticate(username=uname, password=upass)
                if user is not None:
                    login(request,user)
                    messages.success(request,'Account Login Successfully !!')
                    return HttpResponseRedirect('/profile/')
        else:
            fm=AuthenticationForm()
        return render(request,"login.html",{"form":fm})
    else:
        return HttpResponseRedirect('/profile/')

#signup
def sign_up(request):

    fm=SignUpForm()
    if request.method=="POST":
        fm=SignUpForm(request.POST)
        if fm.is_valid():
            messages.success(request,'Account Created Successfully !!')
            fm.save()
        fm=SignUpForm()
    else:
        fm=SignUpForm()
    return render(request,"signup.html",{"form":fm})

def user_logout(request):
    logout(request)
    return HttpResponseRedirect('/login/')


def booking(request):
    if request.method=="POST":
        dm=BookingForm(request.POST)
        if dm.is_valid():
            dm.save()
        dm=BookingForm()
    else:
        dm=BookingForm()
    return render(request,'booking.html',{"dm":dm})

def previous(request):
    user = request.user
    user_bookings = UserBooking.objects.filter(user=user).order_by('Date')
    return render(request, 'previous.html', {'books': user_bookings, 'users': request.user})

def help(request):
    return render(request,"help.html")


def delete_booking(request, booking_id):
    booking = get_object_or_404(UserBooking, pk=booking_id)
    if request.method == 'POST':
        booking.delete()
        return redirect('previous')


